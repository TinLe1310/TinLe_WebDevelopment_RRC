var form;
var fullname;
var email;
var phone;
var comments;



window.addEventListener("load", (e) =>
{
    form = document.getElementById("form");
    fullname = document.getElementById("fullname");
    email = document.getElementById("email");
    phone = document.getElementById("phone");
    comments = document.getElementById("comments");

    if(form !== null)
    {
    form.addEventListener('submit', e =>{
        e.preventDefault();
        validateInputs();
    });
    }
})

const errorInput = (element, message) => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');
    errorDisplay.innerText = message
    inputControl.classList.add('error');
    inputControl.classList.remove('success');
}

const successInput = element => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');
    errorDisplay.innerText = ''
    inputControl.classList.add('success');
    inputControl.classList.remove('error');
}

function validateInputs()
{
    const fullNameValue = fullname.value.trim();
    const emailValue = email.value.trim();
    const phoneValue = phone.value.trim();
    const commentsValue = comments.value.trim();
    const nameRegex = new RegExp('[0-9!@#\$%\^\&*\)\(+=._-]');
    const emailRegex = new RegExp('^\\w+([\.-]?\\w+)*@\\w+([\.-]?\\w+)*(\.\\w{2,3})+$');;

    //////////////////////////////
    if(fullNameValue === "")
    {
        errorInput(fullname, "Please enter your name here")
    }
    else if(nameRegex.test(fullNameValue))
    {
        errorInput(fullname, "That's an invalid name!")
    }
    else
    {
        successInput(fullname);
    }

    //////////////////////////////

    if(emailValue === "")
    {
        errorInput(email, "Please enter your email")
    }
    else if(!emailRegex.test(emailValue))
    {
        errorInput(email, "That's an invalid email!")
    }
    else
    {
        successInput(email)
    }

    //////////////////////////////

    if(phoneValue === "")
    {
        errorInput(phone, "Please enter your phone number")
    }
    else if(phoneValue.length !== 10)
    {
        errorInput(phone, "Invalid Phone Number")
    }
    else
    {
        successInput(phone)
    }

    //////////////////////////////

    if(commentsValue === "")
    {
        errorInput(comments, "Please enter your comments")
    }
    else if(commentsValue.length < 20)
    {
        errorInput(comments, "Comments are too short!")
    }
    else
    {
        successInput(comments)
    }
}