import "./styles.css";
import "mvp.css";
import React, { useState, useEffect } from "react";

// Fetching Data from API link
function FetchingFishWatch(url) {
  const [fish, setFish] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const response = await fetch(url);
      const json = await response.json();
      setFish(json);
    }
    fetchData();
  }, [url]);

  return fish;
}

function CreateFishCard({ fish, input, buttonEnable }) {
  const [data, setData] = useState([]);

  useEffect(() => {
    if (buttonEnable) {
      let fishList = [];
      if (Array.isArray(fish)) {
        fishList = fish;
      } else if (typeof fish === "object") {
        fishList = Object.values(fish);
      }

      setData(
        fishList.filter((item) =>
          item["Species Name"].toLowerCase().includes(input.toLowerCase())
        )
      );
    }
  }, [fish, input, buttonEnable]);

  return (
    <div className="container">
      {buttonEnable ? (
        Array.isArray(data) && data.length > 0 ? (
          data.map(
            ({
              "Species Name": name,
              "Scientific Name": scientific_name,
              Population: population,
              "Species Illustration Photo": image
            }) => (
              <div key="scientific_name" id="fish_card">
                <img src={image.src} alt={name} />
                <h2>{name}</h2>
                <p className="science">Scientific Name🧬: {scientific_name}</p>
                <p>Population🐟: {population}</p>
                <button
                  onClick={() =>
                    alert("Cannot go outside 😥, please turn back!")
                  }
                >
                  Details
                </button>
              </div>
            )
          )
        ) : (
          <p> Cannot find any species with your keywords 😥 </p>
        )
      ) : null}
    </div>
  );
}

// Display Index on Screen for Searching
function SearchingFish({ searchingButtonClicked }) {
  return (
    <>
      <h1>📺 FishWatch 📺</h1>
      <p>
        A searching tool assisting in tracking and searching your favorite
        species.
      </p>
      <div className="search_index">
        <input
          id="search_bar"
          type="text"
          placeholder="Searching your favorite fish 🐟🐡🐠"
        />
        <button id="search_button" onClick={searchingButtonClicked}>
          🔎
        </button>
      </div>
    </>
  );
}

export default function App() {
  const [input, setInput] = useState("");
  const [buttonEnable, setButtonEnable] = useState(false);
  const fish = FetchingFishWatch("https://www.fishwatch.gov/api/species");

  function searchingButtonClicked(e) {
    setButtonEnable(true);
    setInput(e.target.previousSibling.value);
  }

  return (
    <>
      <SearchingFish searchingButtonClicked={searchingButtonClicked} />

      <CreateFishCard fish={fish} input={input} buttonEnable={buttonEnable} />
    </>
  );
}
