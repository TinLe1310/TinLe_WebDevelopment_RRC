<?php

/*******w******** 
    
    Name: Tin Le
    Date: 01/23/2023
    Description: Assignment 3 - New post page to create a new blog

****************/

require('connect.php');
require('authenticate.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>My Blog Post!</title>
</head>
<body>
    <!-- Remember that alternative syntax is good and html inside php is bad -->
    <div id="header">
        <img src="images/scotish.png" alt="cat">
        <h1><a href="index.php">Tin Le - Blogs</a></h1>
    </div>
    <div id="wrapper">
        <ul id="breadcrum">
            <li>
                <a href="index.php" class ="homepage">Home</a>
            </li>
            <li>
                <a href="post.php">New Post</a>
            </li>
        </ul>
    </div>
    <div id="all_blogs">  
        <form method="post" id="form" action="insert.php"> 
            <h2>Create a new blog</h2>
            <ul id="post_input">
                <li>Title</li>    
                <li><input type="text" id="input-title" name="title"></li>
                <li>Content</li>    
                <li><textarea id="input-content" name="content"></textarea></li>
                <li><input type="submit" id="button" value="Submit Blog"></li>
            </ul>
        </form>
    </div>
    <div id="footer">
        <p>Copywrong 2023 - No rights Reserved</p>
    </div>
</body>
</html>