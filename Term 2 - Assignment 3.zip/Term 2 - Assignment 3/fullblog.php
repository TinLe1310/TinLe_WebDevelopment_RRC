<?php

/*******w******** 
    
    Name: Tin Le
    Date: 01/23/2023
    Description: Assignment 3 - Full blog page to show the detailed blog

****************/

require('connect.php');

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if(!$id){
    header("Location: index.php");
    exit;
}

if(isset($_GET['id'])){
    // SQL is written as a String.
    $query = "SELECT * FROM blogs WHERE id = {$_GET['id']}";
} else $query = "SELECT * FROM blogs ORDER BY blogs.id DESC LIMIT 5";

    // A PDO::Statement is prepared from the query.
    $statement = $db->prepare($query);

    // Execution on the DB server is delayed until we execute().
    $statement->execute(); 
    $blog = $statement->fetch();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>My Blog - <?= $blog['title'] ?></title>
</head>
<body>
    <!-- Remember that alternative syntax is good and html inside php is bad -->
    <div id="header">
        <h1><a href="index.php">Tin Le - Blogs</a></h1>
    </div>

    <div id="wrapper">
        <ul id="breadcrum">
            <li>
                <a href="index.php" class ="homepage">Home</a>
            </li>
            <li>
                <a href="post.php">New Post</a>
            </li>
        </ul>
    </div>

    <div id="all_blogs">    
        <ul id="blogs">
            <li class="title">
                <?php $title = $blog['title']?>
                <?= $blog['title'] ?>
                <a href="edit.php" class="editlink">Edit</a>
            </li>
            <li class="date">
                <?php $dateformat = strtotime($blog['date']); ?>
                <?= date('F d, Y, h:ia', $dateformat) ?>
            </li>   
            <li class="content"><?= $blog['content'] ?></li> 
        </ul>             
    </div>

    <div id="footer">
        <p>Copywrong 2023 - No rights Reserved</p>
    </div>
</body>
</html>