<?php

/*******w******** 
    
    Name: Tin Le
    Date: 01/23/2023
    Description: Assignment 3 - Edit page to update and delete the blog

****************/

require('connect.php');
require('authenticate.php');
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if(!$id){
    header("Location: index.php");
    exit;
}

if(isset($_GET['id'])){
    // SQL is written as a String.
    $query = "SELECT * FROM blogs WHERE id = {$_GET['id']}";
} else $query = "SELECT * FROM blogs ORDER BY blogs.id DESC LIMIT 5";

    // A PDO::Statement is prepared from the query.
    $statement = $db->prepare($query);

    // Execution on the DB server is delayed until we execute().
    $statement->execute(); 
    $blog = $statement->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>Edit this Post!</title>
</head>
<body>
    <!-- Remember that alternative syntax is good and html inside php is bad -->
    <div id="header">
        <img src="images/scotish.png" alt="cat">
        <h1><a href="index.php">Tin Le - Blogs</a></h1>
    </div>
    <div id="wrapper">
        <ul id="breadcrum">
            <li>
                <a href="index.php" class ="homepage">Home</a>
            </li>
            <li>
                <a href="post.php">New Post</a>
            </li>
        </ul>
    </div>
    <div id="all_blogs">
        <form method="post" id="form" action="insert.php"> 
            <h2>Edit Page</h2>
            <ul id="post_input">
                <li>Title</li>    
                <li><input type="text" id="input-title" name="title" value = "<?= $blog['title']?>"></li>
                <li>Content</li>    
                <li><textarea id="input-content" name="content"><?= $blog['content'] ?></textarea></li>
                <li><input name="id" type="hidden" value="<?= $blog['id']?>"></li>
                <li id="btn">
                    <input type="submit" id="button" name="update-button" value="Update Blog">
                </li>
                <li id="del"> 
                  <input type="submit" id="delete-button" name="delete-button" value="Delete Blog" onclick="return confirm('Are you sure to delete this blog?')">             
                </li>
            </ul>
        </form>
    </div>
    <div id="footer">
        <p>Copywrong 2023 - No rights Reserved</p>
    </div>
</body>
</html>