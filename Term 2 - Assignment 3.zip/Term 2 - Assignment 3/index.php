<?php

/*******w******** 
    
    Name: Tin Le
    Date: 01/23/2023
    Description: Assignment 3 - Index Home page

****************/

require('connect.php');

// SQL is written as a String.
$query = "SELECT * FROM blogs ORDER BY blogs.id DESC LIMIT 5";

 // A PDO::Statement is prepared from the query.
$statement = $db->prepare($query);

// Execution on the DB server is delayed until we execute().
$statement->execute(); 

// Truncated string for the blog over 200 characters. 
$length = 200;

function truncate($text, $length) {
    if ($length >= \strlen($text)) {
        return $text;
    }

    return preg_replace("/^(.{1,$length})(\s.*|$)/s",'\\1...',$text);
} 

function filter(){
    return filter_input(INPUT_GET, 'id',FILTER_VALIDATE_INT) && $_GET['id'] > 0;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>Welcome to my Blog!</title>
</head>
<body>
    <!-- Remember that alternative syntax is good and html inside php is bad -->
    <div id="header">
        <img src="images/scotish.png" alt="cat">
        <h1>Welcome to Tin Blogs</h1>
    </div>
    <div id="wrapper">
        <ul id="breadcrum">
            <li>
                <a href="index.php" class ="homepage">Home</a>
            </li>
            <li>
                <a href="post.php">New Post</a>
            </li>
        </ul>
    </div>

    <div id="all_blogs">
        <h2>Recently Posted Blog Entries</h2>
        <?php if($statement->rowCount() == 0): ?>
            <h2>No blogs posted.</h2>
        <?php elseif($statement->rowCount() > 0): ?>
            <ul id="blogs">
                <?php while($row = $statement->fetch()): ?>                
                    <li class="title">
                        <a href= "fullblog.php?id=<?=$row['id']?>" class ="titlelink" ><?= $row['title'] ?></a>
                        <a href="edit.php?id=<?=$row['id']?>" class="editlink">Edit</a>
                        <input name="id" type="hidden" value="<?= $row['id'] ?>">
                    </li>
                    <li class="date">
                        <?php $dateformat = strtotime($row['date']); ?>
                        <?= date('F d, Y, h:ia', $dateformat) ?>
                    </li>   
                    <li class="content">
                        <?php if($length < strlen($row['content'])):?>
                            <p><?= truncate($row['content'], $length) ?></p>
                            <a href="fullblog.php?id=<?=$row['id']?>" class="fullpage">Read Full Post</a>
                        <?php else: ?>
                            <p><?= $row['content'] ?></p>
                        <?php endif ?>
                    </li>                    
                <?php endwhile ?>
            </ul>
        <?php endif ?>
    </div>

    <div>
        <?php if(filter()): ?>
            <?php header("Location: getindex.php/?id={$_GET['id']}") ?>
        <?php endif ?>
    </div>
    
    <div id="footer">
        <p>Copywrong 2023 - No rights Reserved</p>
    </div>
</body>
</html>