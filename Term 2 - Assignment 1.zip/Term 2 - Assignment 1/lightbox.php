<?php

/*******w******** 
    
    Name: Tin Le
    Date: 08/01/2023
    Description: Assignment 1 PHP

****************/

$config = [

    'gallery_name' => 'Tin Le Gallery',
 
    'unsplash_categories' => ['Animals','Food','Culture','Human', 'City', 'Music', 'Vehicle', 'Vietnam'],
 
    'local_images' => [
        'British Shorthair' => ['photographer' => 'hang niu', 'homepage' => 'https://unsplash.com/@niuhang'],
        'Maine Coon' => ['photographer' => 'Zoë Gayah Jonker', 'homepage'=> 'https://unsplash.com/@zoegayah'],
        'Ragdoll' => ['photographer' => '毛 祥', 'homepage' => 'https://unsplash.com/@mw960367054'],
        'Abyssinian' => ['photographer' => 'Timo Volz', 'homepage' => 'https://unsplash.com/@magict1911']
        ]
 
];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/luminous-lightbox/2.0.1/luminous-basic.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/luminous-lightbox/2.0.1/Luminous.min.js"></script>
    <title>Assignment 1 - Extra Challenge</title>
</head>
<body>
    <!-- Remember that alternative syntax is good and html inside php is bad -->
    <h1 class="title"><?= $config['gallery_name'] ?></h1>
    <h1 class="title"><?= count($config['local_images'])?> Large Images</h1> 
    <div id="local_images">
        <?php foreach($config['local_images'] as $image => $source): ?>
            <div>
                <a href="images/<?= $image ?>.jpg">
                    <img src="images/<?= $image ?>_thumbnail.jpg" alt="<?= $image ?> image">
                </a>               
            </div> 
        <?php endforeach ?>   
    </div>
<script>
    new LuminousGallery(document.querySelectorAll(".image a"));
</script>
    
</body>
</html>