<?php

/*******w******** 
    
    Name: Tin Le
    Date: 08/01/2023
    Description: Assignment 1 PHP

****************/

$config = [

    'gallery_name' => 'Tin Le Gallery',
 
    'unsplash_categories' => ['Animals','Food','Culture','Human', 'City', 'Music', 'Vehicle', 'Vietnam'],
 
    'local_images' => [
        'British Shorthair.jpg' => ['photographer' => 'hang niu', 'homepage' => 'https://unsplash.com/@niuhang'],
        'Maine Coon.jpg' => ['photographer' => 'Zoë Gayah Jonker', 'homepage'=> 'https://unsplash.com/@zoegayah'],
        'Ragdoll.jpg' => ['photographer' => '毛 祥', 'homepage' => 'https://unsplash.com/@mw960367054'],
        'Abyssinian.jpg' => ['photographer' => 'Timo Volz', 'homepage' => 'https://unsplash.com/@magict1911']
        ]
 
];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title><?= $config['gallery_name'] ?></title>
</head>
<body>
    <!-- Remember that alternative syntax is good and html inside php is bad -->
    <h1 class="title"><?= $config['gallery_name'] ?></h1>
    <div id="gallery">
        <?php foreach($config['unsplash_categories'] as $category): ?>
            <div>
                <h2><?= $category ?></h2>
                <img src="https://source.unsplash.com/300x200/?<?= $category ?>" alt="<?= $category ?> image">
            </div>
        <?php endforeach ?>
    </div>

    <h1 class="title"><?= count($config['local_images'])?> Large Images</h1> 
    <div id="local_images">
        <?php foreach($config['local_images'] as $image => $source): ?>
            <div>
                <img src="images/<?= urlencode($image) ?>" alt="<?= $image ?> image">
                <p><a href="<?= $source['homepage']?>"><?= $source['photographer'] ?></a></p>
            </div> 
        <?php endforeach ?>   
    </div>
    
</body>
</html>