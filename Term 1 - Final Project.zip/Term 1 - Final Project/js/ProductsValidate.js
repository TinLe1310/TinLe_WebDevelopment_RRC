/********f***********
    
	Project 3 Javascript
	Name: Tin Le
	Date: 2022-11-17
	Description: Project 3 - Form validation

********************/

const itemDescription = ["Air Jordan 1 Fragment - High", "Air Jordan 1 Fragment - Low", "Air Jordan 1 Mocha - High", "Air Jordan 1 Mocha - Low", "Air Jordan 1 Reverse Mocha - Low"];
const itemPrice = [3879.99, 1321.99, 2023.99, 2475.99, 1423.99];
const itemImage = ["AJ1-FH.jpg", "AJ1-FL.jpg", "AJ1-HM.jpg", "AJ1-LM.jpg", "AJ1-RL.jpg"];
let numberOfItemsInCart = 0;
let orderTotal = 0;

/*
 * Handles the submit event of the survey form
 *
 * param e  A reference to the event object
 * return   True if no validation errors; False if the form has
 *          validation errors
 */
function validate(e) 
{
	// Hides all error elements on the page
	hideErrors();

	// Determine if the form has errors
	if (formHasErrors(e)) {
		// Prevents the form from submitting
		e.preventDefault();

		// When using onSubmit="validate()" in markup, returning false would prevent
		// the form from submitting
		return false;
	}

	// When using onSubmit="validate()" in markup, returning true would allow
	// the form to submit
	return true;
}

/*
 * Handles the reset event for the form.
 *
 * param e  A reference to the event object
 * return   True allows the reset to happen; False prevents
 *          the browser from resetting the form.
 */
function resetForm(e) 
{
	// Confirm that the user wants to reset the form.
	if (confirm('Clear order?')) {
		// Ensure all error fields are hidden
		hideErrors();

		// Set focus to the first text field on the page
		document.getElementById("qty1").focus();

		// When using onReset="resetForm()" in markup, returning true will allow
		// the form to reset
		return true;
	}

	// Prevents the form from resetting
	e.preventDefault();

	// When using onReset="resetForm()" in markup, returning false would prevent
	// the form from resetting
	return false;
}

/*
 * Does all the error checking for the form.
 *
 * return   True if an error was found; False if no errors were found
 */
function formHasErrors(e) 
{
	const postalRegex = new RegExp(/^[ABCEGHJKLMNPRSTVXY]\d[ABCEGHJKLMNPRSTVXY][ -]?\d[ABCEGHJKLMNPRSTVXY]\d$/i);
	const emailRegex = new RegExp('[a-z0-9]+@[a-z]+\.[a-z]{2,3}');
	let month = document.getElementById("month");
	let year = document.getElementById("year");
	const convertedExpiryDate = new Date (year.value, month.value -1).getTime();
	const currentDate = new Date();

	// Determine if any items are in the cart
	// When the cart has not items, submission of form is halted
	if (numberOfItemsInCart == 0) 
	{
		// Display an error message contained in a modal dialog element

		const modal = document.querySelector("#cartError");
		modal.showModal();

		const closeModal = document.querySelector(".close-button");

		closeModal.addEventListener("click", () => 
		{
			modal.close();
			document.getElementById("qty1").focus();
		});

		alert("You have no items in your cart");

		// Form has errors
		return true;
	} 

	//	Complete the validations below
	// Determine if the shipping information is valid
	// When the information is empty, submission of form is  halted

	let shippingInformation = ["fullname", "address", "city", "postal", "email"];
	let paymentInformation = ["visa", "amex", "mastercard"];
	let cardInformation = ["cardname", "month", "cardnumber"];
	let paymentChecked = false;
	let result = false;

	// Shipping Information

	for (let i = 0; i < shippingInformation.length; i++)
	{
		if (e.target[shippingInformation[i]].value === "")
		{
			let errorDetail = shippingInformation[i];
			const error = document.getElementById(errorDetail+"_error");
			error.style.display = "block";
			result = true;
		}

		if (shippingInformation[i] == "postal")
		{
			if (!postalRegex.test(e.target[shippingInformation[i]].value))
			{
				let errorDetail = shippingInformation[i];
				const formatError = document.getElementById(errorDetail+"format_error");
				formatError.style.display = "block";
				result = true;
			}
		}

		if (shippingInformation[i] == "email")
		{
			if (!emailRegex.test(e.target[shippingInformation[i]].value))
			{
				let errorDetail = shippingInformation[i];
				const formatError = document.getElementById(errorDetail+"format_error");
				formatError.style.display = "block";
				result = true;
			}
		}
	}

	// Card Type Information

	for (let i = 0; i < paymentInformation.length && !paymentChecked; i++)
	{
		if (e.target[paymentInformation[i]].checked)
		{
			paymentChecked = true;
		}
	}

	if (!paymentChecked)
	{
		const cardtypeError = document.getElementById("cardtype_error");
		cardtypeError.style.display = "block";
		result = true;
	}
	

	// Card Information

	for (let i = 0; i < cardInformation.length; i++)
	{
		if (e.target[cardInformation[i]].value === "" || e.target[cardInformation[i]].value == "- Month -")
		{
			let errorDetail = cardInformation[i];
			const error = document.getElementById(errorDetail+"_error");
			error.style.display = "block";
			result = true;
		}

		// Expiry Date Check

		if (cardInformation[i] == "month")
		{
			if (currentDate > convertedExpiryDate)
			{
				const expiryError = document.getElementById("expiry_error");
				expiryError.style.display = "block";
				result = true;
			}
		}

		// Validate Card Number

		if(cardInformation[i] == "cardnumber")
		{
			if(!validateCardNumber(e.target[cardInformation[i]].value))
			{
				const invalidCardError = document.getElementById("invalidcard_error");
				invalidCardError.style.display = "block";
				result = true;
			}
		}
	}

	if (result)
	{
		return true;
	}
}

function validateCardNumber(cardNumber)
{
	let validCard = true;

	if (cardNumber.length != 10)
	{
		validCard = false;
	}
	else
	{
		const cardNumberDigits = cardNumber.toString().split('');
		let cardNumberNumbers = [];

		for (let i = 0; i < cardNumberDigits.length; i++)
		{
			cardNumberNumbers.push(parseInt(cardNumberDigits[i]));
		}

		const checkingFactor = 432765432;
		const checkingFactorDigits = checkingFactor.toString().split('');
		let checkingFactorNumbers = [];
		let sum = 0;

		for (let i = 0; i < checkingFactorDigits.length; i++)
		{
			checkingFactorNumbers.push(parseInt(checkingFactorDigits[i]));
		}

		for (let i = 0; i < checkingFactorNumbers.length; i++)
		{
			sum += checkingFactorNumbers[i] * cardNumberNumbers[i];
		}

		let remainder = 11 - (sum % 11);

		if (remainder != cardNumberNumbers[cardNumberDigits.length-1])
		{
			validCard = false;
		}
	}	

	return validCard;
}

/*
 * Adds an item to the cart and hides the quantity and add button for the product being ordered.
 *
 * param itemNumber The number used in the id of the quantity, item and remove button elements.
 */
function addItemToCart(itemNumber) 
{
	// Get the value of the quantity field for the add button that was clicked 
	let quantityValue = trim(document.getElementById("qty" + itemNumber).value);

	// Get the value of the size field for the add button that was clicked
	let sizeValue = trim(document.getElementById("size" + itemNumber).value);

	// Determine if the quantity value is valid
	if (!isNaN(quantityValue) && quantityValue != "" && quantityValue != null && quantityValue != 0 && !document.getElementById("cartItem" + itemNumber)) {
		// Hide the parent of the quantity field being evaluated
		document.getElementById("qty" + itemNumber).parentNode.style.visibility = "hidden";

		// Determine if there are no items in the cart
		if (numberOfItemsInCart == 0) {
			// Hide the no items in cart list item 
			document.getElementById("noItems").style.display = "none";
		}

		// Create the image for the cart item
		let cartItemImage = document.createElement("img");
		cartItemImage.src = "images/" + itemImage[itemNumber - 1];
		cartItemImage.alt = itemDescription[itemNumber - 1];

		// Create the span element containing the item description
		let cartItemDescription = document.createElement("span");
		cartItemDescription.innerHTML = itemDescription[itemNumber - 1];

		// Create the span element containing the size to order
		let cartItemSize = document.createElement("span");
		cartItemSize.innerHTML = sizeValue;

		// Create the span element containing the quanitity to order
		let cartItemQuanity = document.createElement("span");
		cartItemQuanity.innerHTML = quantityValue;

		// Calculate the subtotal of the item ordered
		let itemTotal = quantityValue * itemPrice[itemNumber - 1];

		// Create the span element containing the subtotal of the item ordered
		let cartItemTotal = document.createElement("span");
		cartItemTotal.innerHTML = formatCurrency(itemTotal);

		// Create the remove button for the cart item
		let cartItemRemoveButton = document.createElement("button");
		cartItemRemoveButton.setAttribute("id", "removeItem" + itemNumber);
		cartItemRemoveButton.setAttribute("type", "button");
		cartItemRemoveButton.innerHTML = "Remove";
		cartItemRemoveButton.addEventListener("click",
			// Annonymous function for the click event of a cart item remove button
			function () 
			{
				// Removes the buttons grandparent (li) from the cart list
				this.parentNode.parentNode.removeChild(this.parentNode);

				// Deteremine the quantity field id for the item being removed from the cart by
				// getting the number at the end of the remove button's id
				let itemQuantityFieldId = "qty" + this.id.charAt(this.id.length - 1);

				// Get a reference to quanitity field of the item being removed form the cart
				let itemQuantityField = document.getElementById(itemQuantityFieldId);

				// Set the visibility of the quantity field's parent (div) to visible
				itemQuantityField.parentNode.style.visibility = "visible";

				// Initialize the quantity field value
				itemQuantityField.value = "";

				// Decrement the number of items in the cart
				numberOfItemsInCart--;

				// Decrement the order total
				orderTotal -= itemTotal;

				// Update the total purchase in the cart
				document.getElementById("cartTotal").innerHTML = formatCurrency(orderTotal);

				// Determine if there are no items in the car
				if (numberOfItemsInCart == 0) {
					// Show the no items in cart list item 
					document.getElementById("noItems").style.display = "block";
				}
			},
			false
		);

		// Create a div used to clear the floats
		let cartClearDiv = document.createElement("div");
		cartClearDiv.setAttribute("class", "clear");

		// Create the paragraph which contains the cart item summary elements
		let cartItemParagraph = document.createElement("p");
		cartItemParagraph.appendChild(cartItemImage);
		cartItemParagraph.appendChild(cartItemDescription);
		cartItemParagraph.appendChild(document.createElement("br"));
		cartItemParagraph.appendChild(document.createElement("br"));
		cartItemParagraph.appendChild(document.createTextNode("Quantity: "));
		cartItemParagraph.appendChild(cartItemQuanity);
		cartItemParagraph.appendChild(document.createElement("br"));
		cartItemParagraph.appendChild(document.createTextNode("Size: "));
		cartItemParagraph.appendChild(cartItemSize);
		cartItemParagraph.appendChild(document.createElement("br"));
		cartItemParagraph.appendChild(document.createTextNode("Total: "));
		cartItemParagraph.appendChild(cartItemTotal);

		// Create the cart list item and add the elements within it
		let cartItem = document.createElement("li");
		cartItem.setAttribute("id", "cartItem" + itemNumber);
		cartItem.appendChild(cartItemParagraph);
		cartItem.appendChild(cartItemRemoveButton);
		cartItem.appendChild(cartClearDiv);

		// Add the cart list item to the top of the list
		let cart = document.getElementById("cart");
		cart.insertBefore(cartItem, cart.childNodes[0]);

		// Increment the number of items in the cart
		numberOfItemsInCart++;

		// Increment the total purchase amount
		orderTotal += itemTotal;

		// Update the total puchase amount in the cart
		document.getElementById("cartTotal").innerHTML = formatCurrency(orderTotal);
	}
}

/*
 * Hides all of the error elements.
 */
function hideErrors() 
{
	// Get an array of error elements
	let error = document.getElementsByClassName("error");

	// Loop through each element in the error array
	for (let i = 0; i < error.length; i++) {
		// Hide the error element by setting it's display style to "none"
		error[i].style.display = "none";
	}
}

/*
 * Handles the load event of the document.
 */
function load() 
{
	// Ensure all error fields are hidden
	hideErrors();
	//	Populate the year select with up to date values
	let year = document.getElementById("year");
	let currentDate = new Date();
	for (let i = 0; i < 7; i++) {
		let newYearOption = document.createElement("option");
		newYearOption.value = currentDate.getFullYear() + i;
		newYearOption.innerHTML = currentDate.getFullYear() + i;
		year.appendChild(newYearOption);
	}

	// Add event listener for the form submit
	document.getElementById("orderform").addEventListener("submit", validate);

	// Add event listener for the form reset
	document.getElementById("clear").addEventListener("reset", resetForm);

	// Add event listener for the item button
	document.getElementById("addMac").addEventListener("click", function(){addItemToCart(1)});
	document.getElementById("addMouse").addEventListener("click", function(){addItemToCart(2)});
	document.getElementById("addWD").addEventListener("click", function(){addItemToCart(3)});
	document.getElementById("addNexus").addEventListener("click", function(){addItemToCart(4)});
	document.getElementById("addDrums").addEventListener("click", function(){addItemToCart(5)});
}

// Add document load event listener
document.addEventListener("DOMContentLoaded", load);












