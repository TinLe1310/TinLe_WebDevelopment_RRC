<?php

/*******w******** 
    
    Assignment 2
    Name: Tin Le
    Date: 10-01-2023
    Description: User input sanitize and validate

****************/

$quantities = [['qty' => 'qty1', 'item' => "MacBook" , 'price' => "1899.99"],
               ['qty' => 'qty2', 'item' => "Razer" , 'price' => "79.99"],
               ['qty' => 'qty3', 'item' => "WD HDD" , 'price' => "179.99"],
               ['qty' => 'qty4', 'item' => "Nexus" , 'price' => "249.99"],
               ['qty' => 'qty5', 'item' => "Drums" , 'price' => "119.99"]]

?>
<?php
    if(isset($_POST)){
    $content = "Thanks for your order {$_POST['fullname']}";
}

$total = 0;
$error = "";

function total($quantity){
    $subtotal = 0;
    $subtotal = $_POST[$quantity['qty']] * $quantity['price'];
    return $subtotal;
}

function validateQuantity($quantities){
    $result = true;
    $count = 0;
    foreach ($quantities as $quantity){
        if ($_POST[$quantity['qty']] !== ''){
            if (!filter_var($_POST[$quantity['qty']], FILTER_VALIDATE_INT)){                 
                     $error = "The quantity of {$quantity['item']} is invalid interger";
                     echo "<h1>$error</h1>";
                     $result = false;  
            }         
        } 
        else $count += 1;
    }

    if ($count == 5){
        $result = false;
        $error = "Your cart is empty. Please choose at least 1 item";
        echo "<h1>$error</h1>";
    }

    return $result;
}

function validate(){
    $conditions = ['fullname' => 'Full Name',
                   'cardname' => 'Card Name',
                   'address' => 'Address',
                   'city' => 'City'];
    $provinces = ['AB', 'BC', 'MB', 'NB', 'NL', 'NS', 'ON', 'PE', 'QC', 'SK', 'NT', 'NU', 'YT'];
    $state = true;
    $min = 1000000000;
    $max = 9999999999;

    if($_POST['email'] === ""){
        $error = "Email is required";
        echo "<h1>$error</h1>";
        $state = false;
    } elseif(!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL)){
        $error = "'{$_POST['email']}' is an invalid Email input.";
        echo "<h1>$error</h1>";
        $state = false;
    }
    
    if($_POST['postal'] === ""){
        $error = "Postal Code is required";
        echo "<h1>$error</h1>";
        $state = false;
    } elseif(!filter_var($_POST['postal'],FILTER_VALIDATE_REGEXP,array("options" => array("regexp"=>"/^([a-zA-Z]\d[a-zA-Z])\ {0,1}(\d[a-zA-Z]\d)$/")))){
        $error = "'{$_POST['postal']}' is an invalid Postal Code input.";
        echo "<h1>$error</h1>";
        $state = false;
    }

    if($_POST['cardnumber'] === ""){
        $error = "Card Number is required";
        echo "<h1>$error</h1>";
        $state = false;
    } elseif(!filter_var($_POST['cardnumber'],FILTER_VALIDATE_INT, array("options" => array("min_range"=>$min, "max_range"=>$max)))){
        $error = "'{$_POST['cardnumber']}' is an invalid Card Number input.";
        echo "<h1>$error</h1>";
        $state = false;
    }

    
    if(!filter_var($_POST['month'],FILTER_VALIDATE_INT, array("options" => array("min_range"=>1, "max_range"=>12)))){
        $error = "Credit Card Month is required";
        echo "<h1>$error</h1>";
        $state = false;
    }

    if(!filter_var($_POST['year'],FILTER_VALIDATE_INT, array("options" => array("min_range"=>2023, "max_range"=>2028)))){
        $error = "Credit Card Year is required";
        echo "<h1>$error</h1>";
        $state = false;
    }

    if(!in_array($_POST['province'], $provinces)){
        $error = "Province is invalid";
        echo "<h1>$error</h1>";
        $state = false;
    }

    if(!isset($_POST['cardtype'])){
        $error = "Card Type is required";
        echo "<h1>$error</h1>";
        $state = false;
    }

    foreach ($conditions as $condition => $param){
        if($_POST[$condition] === ''){
            $error = "$param is required";
            echo "<h1>$error</h1>";
            $state = false;
        }
    }

    return $state;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>Thanks for your order!</title>
</head>
<body>
    <!-- Remember that alternative syntax is good and html inside php is bad -->
    <?php if(validate() && validateQuantity($quantities)):?>
        <div class='invoice'>
            <h1><?= $content ?></h1>
            <h2>Here's a summary of your order:</h2>
            <table>
            <tr>
                <th colspan = "4">Address Information</th>
            </tr>
            <tr>
                <td class ='alignright'>Address:</td>
                <td><?= $_POST['address']?></td>
                <td class ='alignright'>City:</td>
                <td><?= $_POST['city']?></td>
            </tr>
            <tr>
                <td class ='alignright'>Province:</td>
                <td><?= $_POST['province']?></td>
                <td class ='alignright'>Postal Code:</td>
                <td><?= $_POST['postal']?></td>
            </tr>
            <tr>
                <td class ='alignright' colspan ="2">Email:</td>
                <td colspan="2"><?= $_POST['email']?></td>
            </tr>
            </table>
            <table>
            <tr>
                <th colspan = "3">Order Information</th>
            </tr>
            <tr>
                <td>Quantity</td>
                <td>Description</td>
                <td>Cost</td>
            </tr>
            <?php foreach($quantities as $quantity): ?>
                <?php if($_POST[$quantity['qty']] >= 1): ?>
                    <tr>
                        <td class ='alignright'><?= $_POST[$quantity['qty']] ?></td>
                        <td class ='alignright'><?= $quantity['item'] ?></td>
                        <td class ='alignright'><?= total($quantity) ?></td>
                    </tr>
                    <?php $total += total($quantity) ?>
                <?php endif ?>
            <?php endforeach ?>
            <tr>
                <td class ='alignright' colspan= "2">Totals</td>
                <td class ='alignright'>$<?= $total ?></td>
            </tr>
            </table>
        </div>
        <div id='crabgif'>
            <?php if($total >= 20000): ?>
                <h2>Thanks you for your huge support! Tin Le loves you bro!!! </h2>
                <iframe src="https://giphy.com/embed/XtydbjSSwkC7K2zBTH" width="650" height="650" class="giphy-embed" allowFullScreen></iframe>
            <?php endif ?>
        </div>
    <?php endif ?>
</body>
</html>